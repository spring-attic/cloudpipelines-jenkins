package io.cloudpipelines.spinnaker.pipeline.model

import groovy.transform.CompileStatic;

@CompileStatic
class AppConfig {
}






